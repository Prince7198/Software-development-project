import * as React from 'react';

//Header
import Header from './components/Header/Header';
//get Homepage
import Homepage from './components/Homepage/Homepage';
//get Footer
import Footer from './components/Footer/Footer';
export default function App() {
  return (
    <>
  
    <Homepage/>
    <Footer />

    </>
    
  );
}

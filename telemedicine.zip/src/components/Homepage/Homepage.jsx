import React from 'react'
import "./Homepage.css";
import Header from '../Header/Header';
const Homepage = () => {
  return (
    <div className='homepage' >
        <Header />
        <div className="buttons">
        <button type="button" className='doctor-login'>Doctor Login</button> <br />
        <button type="button" className='patient-login'>Patient Login</button> 
      </div>    
    </div>
  )
}

export default Homepage
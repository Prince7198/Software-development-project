import React from 'react'

const Doctor = () => {
  return (
    <div>Doctor</div>
  )
}

export default Doctor
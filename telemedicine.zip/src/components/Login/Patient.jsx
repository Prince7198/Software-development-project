import React from 'react'

const Patient = () => {
  return (
    <div>Patient</div>
  )
}

export default Patient
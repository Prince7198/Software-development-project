import React, {useState,useEffect} from 'react';
import logo from "/src/assets/logo.png";
import "./Header.css"

const Header =()=>{
  return (
    <div className='header'>
      <nav >
        <a href="/home">
          <img src={logo} alt="logo" width={100} height={100}/>
        </a>
        <div >
          <ul className='navbar'>
            <li>
              <a href="/home"> Home</a>
            </li>
            <li>
              <a href="/contact Us"> Contact Us</a>
            </li>
            <li>
              <a href="/blog"> Blog</a>
            </li>
          </ul>
        </div>
      </nav>        
    </div>
  )
}
export default Header
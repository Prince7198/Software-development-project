import React from 'react'

const Register = () => {
  return (
    <div>Patient Register</div>
  )
}

export default Register
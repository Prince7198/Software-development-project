import React from 'react'

const Register = () => {
  return (
    <div>Doctor Register</div>
  )
}

export default Register
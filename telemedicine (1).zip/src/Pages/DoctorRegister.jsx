import React from 'react';
import Header from '../components/Header/Header';
import Footer from '../components/Footer/Footer';
import Register from '../components/Register/Doctor/Register';

const DoctorRegister = () => {
  return (
    <div>
        <Header/>
        < Register/>
        
        <Footer />
    </div>
  )
}

export default DoctorRegister
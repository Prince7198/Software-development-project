import React from 'react';
import "./Login.css";
import { Link } from 'react-router-dom';

const Doctor = () => {
  return (
    <div className='dbody'>
       <h1 className='dtitle'>Doctor Login</h1>
       <form className="dform" >
        <label htmlFor="input">Staff Number</label><br /> <br />
        <input type="text" placeholder='Enter your Staff Number' id='staffnumber' required /><br /><br />
        <label htmlFor="input">Password</label><br /> <br />
        <input type="password" placeholder='Enter your Password'  required /> <br /><br />
        <button className='dbtnSubmit' type="submit" >Login</button>
       </form> 
       <div className="dsignup">
        <p style={{color:"white"}}>Don't have an account? </p><Link to="/doctor-register"><u> Sign up</u> </Link></div>     

    </div>
  )
}

export default Doctor
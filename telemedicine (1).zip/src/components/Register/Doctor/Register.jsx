import React from 'react';
import "./Register.css";
import { Link } from 'react-router-dom';

const Register = () => {

  //handle submit action
  const handleSubmit = (e)=>{
    e.preventDefault();


  }
  return (
    <div className='drbody'>
      <div>
        <h1 className='drtitle'>Doctor Registration</h1>
       <form className="drform" onSubmit={handleSubmit}>
        <label htmlFor="input-button">Staff Number</label><br /> <br />
        <input type="text" placeholder='Enter your Staff Number' id='staffnumber' required /><br /><br />
        <label htmlFor="input-button">Full Names</label><br /> <br />
        <input type="text" placeholder='Enter your Full Names' id='staffnames' required /> <br /><br />
        <label htmlFor="input-button">Staff Password</label><br /> <br />
        <input type="text" placeholder='Enter your Password' id='staffpassword' required /><br /><br />
        <label htmlFor="input-button">Confirm Password</label><br /> <br />
        <input type="text" placeholder='Confirm your Password' id='staffcpassword' required /> <br /><br /><br />
        <button className='drbtnSubmit' type="submit" >Submit</button>
       </form>
      </div>
      <div className="dsignup">
        <p style={{color:"white"}}>Already have an account? </p><Link to="/doctor-login"><u> Log in</u> </Link></div>     

      
    </div>
  )
}

export default Register